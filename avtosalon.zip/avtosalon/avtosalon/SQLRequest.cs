﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace avtosalon
{
    static class SQLRequest
    {
        static public int Login(string login, string password)
        {
            DB db = new DB("Avtosalon");
            db.openConnection();

            SqlCommand command = new SqlCommand(
                "SELECT Id FROM Users WHERE Login = @Login AND Password = @Password",
                db.getConnection());
            command.Parameters.AddWithValue("Login", login);
            command.Parameters.AddWithValue("Password", password);

            int answer;
            using (SqlDataReader reader = command.ExecuteReader())
            {
                reader.Read();
                if (reader.HasRows)
                    answer = Convert.ToInt16(reader[0]);
                else
                    answer = -1;
            }

            db.closeConnection();
            return answer;
        }
        static public int Register(string login, string password)
        {
            DB db = new DB("Avtosalon");
            db.openConnection();

            SqlCommand command = new SqlCommand(
                "INSERT INTO Users (Login, Password) VALUES (@Login, @Password)",
                db.getConnection());
            command.Parameters.AddWithValue("Login", login);
            command.Parameters.AddWithValue("Password", password);
            int answer = 0;
            try
            {
                answer = command.ExecuteNonQuery();
            }
            catch
            {
                MessageBox.Show("Регистрация не была завершена, возможно выбранный вами логин уже занят!");
            }

            db.closeConnection();
            return answer;
        }
        static public int ChangePswd(int id, string oldPassword, string newPassword)
        {
            DB db = new DB("Avtosalon");
            db.openConnection();

            SqlCommand command = new SqlCommand(
               "UPDATE Users SET Password=@NewPassword WHERE Id=@Id AND Password=@Old_password",
               db.getConnection());
            command.Parameters.AddWithValue("Id", id);
            command.Parameters.AddWithValue("Old_password", oldPassword);
            command.Parameters.AddWithValue("NewPassword", newPassword);

            int answer = command.ExecuteNonQuery();

            db.closeConnection();
            return answer;
        }
    }
}
