﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace avtosalon
{
    public partial class ChangePswd : Form
    {
        public ChangePswd()
        {
            InitializeComponent();

            label1.BackColor = Color.Transparent;
            label1.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Bold);

            label2.BackColor = Color.Transparent;
            label2.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Bold);

            label3.BackColor = Color.Transparent;
            label3.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Bold);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.closeForm();
        }

        private void ChangePswd_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.closeForm();
        }

        private void closeForm()
        {
            this.Hide();
            MainWindow mainForm = this.Owner as MainWindow;
            if (mainForm != null)
            {
                mainForm.Show();
            }
        }

        private void button_change_Click(object sender, EventArgs e)
        {
            MainWindow mainForm = this.Owner as MainWindow;
            if (mainForm != null)
            {
                if ((!string.IsNullOrEmpty(OldPassword.Text) && !string.IsNullOrWhiteSpace(OldPassword.Text))
                && (!string.IsNullOrEmpty(NewPassword.Text) && !string.IsNullOrWhiteSpace(NewPassword.Text))
                && (!string.IsNullOrEmpty(Confirm.Text) && !string.IsNullOrWhiteSpace(Confirm.Text)))
                {
                    if (OldPassword.Text.Length > 16 || OldPassword.Text.Length < 6
                            || NewPassword.Text.Length > 16 || NewPassword.Text.Length < 6)
                        MessageBox.Show("Введите пароль не менее 6 символов, но не более 16");
                    else
                    {
                        if (NewPassword.Text != Confirm.Text)
                            MessageBox.Show("Пароли не совпадают!");
                        else
                        {
                            int id_user = mainForm.Id_user;
                            int isChanged = SQLRequest.ChangePswd(id_user,
                                MySHA256.hash(OldPassword.Text), MySHA256.hash(NewPassword.Text));
                            if (isChanged == 1)
                            {
                                MessageBox.Show("Пароль успешно изменен!");
                                this.Hide();
                            }
                            else
                                MessageBox.Show("Неверный текущий пароль!");
                        }
                    }
                }
            }
        }
    }
}
