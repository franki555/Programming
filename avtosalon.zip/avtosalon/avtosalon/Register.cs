﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace avtosalon
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();

            label1.BackColor = Color.Transparent;
            label1.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Bold);

            label2.BackColor = Color.Transparent;
            label2.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Bold);

            label3.BackColor = Color.Transparent;
            label3.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Bold);
        }

        private void button_back_Click(object sender, EventArgs e)
        {
            this.Hide();
            Authentification authentificationForm = this.Owner as Authentification;
            if (authentificationForm != null)
            {
                authentificationForm.Show();
            }
        }

        private void Register_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button_register_Click(object sender, EventArgs e)
        {
            if ((!string.IsNullOrEmpty(Login.Text) && !string.IsNullOrWhiteSpace(Login.Text))
                && (!string.IsNullOrEmpty(Password.Text) && !string.IsNullOrWhiteSpace(Password.Text))
                && (!string.IsNullOrEmpty(Confirm.Text) && !string.IsNullOrWhiteSpace(Confirm.Text))
                && (!CheckForbiddenChar.check(Login.Text)))
            {
                if (Login.Text.Length > 16 || Login.Text.Length < 6
                        || Password.Text.Length > 16 || Password.Text.Length < 6)
                    MessageBox.Show("Введите логин или пароль не менее 6 символов, но не более 16");
                else
                {
                    if (Password.Text != Confirm.Text)
                        MessageBox.Show("Пароли не совпадают!");
                    else
                    {
                        int isReg = SQLRequest.Register(Login.Text, MySHA256.hash(Password.Text));
                        if (isReg != 0)
                        {
                            MessageBox.Show("Регистрация прошла успешно!");
                            this.Hide();
                            Authentification authentificationForm = this.Owner as Authentification;
                            if (authentificationForm != null)
                            {
                                authentificationForm.Show();
                            }
                        }
                        else
                            MessageBox.Show("Логин занят!");
                    }
                }
            }
            else
                MessageBox.Show("Все поля должны быть заполнены без запрещенных символов!");
        }
    }
}
