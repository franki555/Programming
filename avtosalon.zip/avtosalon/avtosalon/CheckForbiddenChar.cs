﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace avtosalon
{
    static class CheckForbiddenChar
    {
        static public bool check(string text)
        {
            char[] forbiddenChar = { '"', '/' };
            for (int i = 0; i < text.Length; i++)
                for (int j = 0; j < forbiddenChar.Length; j++)
                    if (text[i] == forbiddenChar[j])
                        return true;
            return false;
        }
    }
}
