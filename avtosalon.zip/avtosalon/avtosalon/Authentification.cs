﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace avtosalon
{
    public partial class Authentification : Form
    {
        public Authentification()
        {
            InitializeComponent();

            label1.BackColor = Color.Transparent;
            label1.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Bold);

            label2.BackColor = Color.Transparent;
            label2.Font = new Font(label1.Font, label1.Font.Style | FontStyle.Bold);
        }

        private void button_register_Click(object sender, EventArgs e)
        {
            Register registerForm = new Register();
            registerForm.Owner = this;
            registerForm.Show();
            this.Hide();
        }

        private void button_login_Click(object sender, EventArgs e)
        {
            if ((!string.IsNullOrEmpty(Login.Text) && !string.IsNullOrWhiteSpace(Login.Text))
                && (!string.IsNullOrEmpty(Password.Text) && !string.IsNullOrWhiteSpace(Password.Text))
                && (!CheckForbiddenChar.check(Login.Text)))
            {
                if (Login.Text.Length > 16 || Login.Text.Length < 6
                        || Password.Text.Length > 16 || Password.Text.Length < 6)
                    MessageBox.Show("Введите логин или пароль не менее 6 символов, но не более 16");
                else
                {
                    int id_user = SQLRequest.Login(Login.Text, MySHA256.hash(Password.Text));
                    if (id_user != -1)
                    {
                        MainWindow mainForm = new MainWindow();
                        mainForm.Owner = this;
                        mainForm.Id_user = id_user;
                        mainForm.Show();
                        this.Hide();
                    }
                    else
                        MessageBox.Show("Неверный логин или пароль!");
                }
            }
            else
                MessageBox.Show("Все поля должны быть заполнены без запрещенных символов!");
        }
    }
}
