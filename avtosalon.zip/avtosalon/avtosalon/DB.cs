﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace avtosalon
{
    interface IDB
    {
        void openConnection();
        void closeConnection();
        SqlConnection getConnection();
        bool status();
    }
    class DB : IDB
    {
        private SqlConnection sqlConnection = null;

        public DB(string connectStr)
        {
            sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings[connectStr].ConnectionString);
        }
        public void openConnection()
        {
            sqlConnection.Open();
        }
        public void closeConnection()
        {
            if (status())
                sqlConnection.Close();
        }
        public SqlConnection getConnection()
        {
            return sqlConnection;
        }
        public bool status()
        {
            return sqlConnection.State == ConnectionState.Open ? true : false;
        }
    }
}
