﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace avtosalon
{
    public partial class MainWindow : Form
    {
        int id_user;
        SqlDataAdapter adapter;
        DataSet ds;

        public int Id_user
        {
            get
            {
                return id_user;
            }
            set
            {
                id_user = value;
            }
        }

        public MainWindow()
        {
            InitializeComponent();

            this.fillDataGrid();
        }

        private void fillDataGrid()
        {
            DB db = new DB("Avtosalon");
            db.openConnection();

            adapter = new SqlDataAdapter(
                "SELECT * FROM Cars", db.getConnection());
            
            ds = new DataSet();
            adapter.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.Columns["Id"].ReadOnly = true;

            db.closeConnection();
        }

        private void MainWindow_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void сменитьПарольToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangePswd changePasswordForm = new ChangePswd();
            changePasswordForm.Owner = this;
            changePasswordForm.Show();
        }

        private void выйтиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Authentification authentification = this.Owner as Authentification;
            if (authentification != null)
            {
                authentification.Show();
            }
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            if (ds.Tables[0].Rows.Count != 0)
            {
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(adapter);
                adapter.Update(ds);
                ds.Clear();
                adapter.Fill(ds);
            }
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            if (ds.Tables[0].Rows.Count != 0)
            {
                int a = dataGridView1.CurrentRow.Index;
                dataGridView1.Rows.Remove(dataGridView1.Rows[a]);
                SqlCommandBuilder commandBuilder = new SqlCommandBuilder(adapter);
                adapter.Update(ds);
                ds.Clear();
                adapter.Fill(ds);
            }
        }

        private void dataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            MessageBox.Show("Неверный тип данных, попробуйте снова!");
        }

        private void button_search_Click(object sender, EventArgs e)
        {
            if ((!string.IsNullOrEmpty(MaxPrice.Text) && !string.IsNullOrWhiteSpace(MaxPrice.Text)))
            {
                DB db = new DB("Avtosalon");
                db.openConnection();

                SqlCommand command = new SqlCommand(
                    "SELECT * FROM Cars WHERE Price<=@Price", db.getConnection());
                command.Parameters.AddWithValue("Price", MaxPrice.Text);
                adapter = new SqlDataAdapter(command);
                ds = new DataSet();
                adapter.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                dataGridView1.Columns["Id"].ReadOnly = true;
                dataGridView1.Columns["Brand"].ReadOnly = true;
                dataGridView1.Columns["Company"].ReadOnly = true;
                dataGridView1.Columns["Release_date"].ReadOnly = true;
                dataGridView1.Columns["Mileage"].ReadOnly = true;
                dataGridView1.Columns["Price"].ReadOnly = true;

                db.closeConnection();
            }
            else
                this.fillDataGrid();
        }
    }
}